package com.sampleproject.springbootbackend.testController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.sampleproject.springbootbackend.controller.EmployeeController;

@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest{

	//@MockBean
	
	
	
	@Test
	public void getAllEmployees() {
		
	}
	
	@Test
	public void createEmployee() {
		
	}
	
	@Test
	public void getEmployeeById() {
		
	}
	
	@Test
	public void updateEmployee() {
		
	}
	
	@Test
	public void deleteEmployee() {
		
	}
}
